export const STARTING_STATE={money:2500,energy:100,missionStep:0,foodBought:false,quizDone:false,paused:false};
const KEY='student-life-campus-alpha-v1';
export function loadState(){try{const saved=JSON.parse(localStorage.getItem(KEY));return saved?{...STARTING_STATE,...saved,paused:false}:{...STARTING_STATE};}catch{return {...STARTING_STATE};}}
export function saveState(state){try{localStorage.setItem(KEY,JSON.stringify({...state,paused:false}));return true;}catch{return false;}}
export function resetState(){try{localStorage.removeItem(KEY);}catch{}return {...STARTING_STATE};}
