# STUDENT LIFE: Campus Alpha

A lightweight, browser-based 3D campus-life prototype. This is an early playable foundation, not a finished game.

## Included
- Procedural 3D campus: gate, hostel, cafeteria, lecture block, campus shop, pitch, paths, trees, benches and bus stop
- Third-person student character with simple walking animation
- Mobile virtual joystick and separate camera-look area
- Keyboard movement (WASD / arrow keys) and E to interact
- First Day on Campus mission: hostel check-in → buy food → complete lecture quiz
- Starter wallet, energy meter, pause menu and local save/restart

## Run it
The project imports Three.js as a browser ES module from jsDelivr, so an internet connection is needed. Serve this folder over HTTP; do not open `index.html` directly with `file://`.

### Easiest: GitHub Pages
1. Create a new GitHub repository.
2. Upload the contents of this folder, keeping the `src` folder.
3. In repository Settings → Pages, publish from the main branch and root folder.
4. Open the published URL on your phone.

### Local computer
From this folder, run `python -m http.server 8000`, then visit `http://localhost:8000` in your browser.

## Controls
- Phone: left joystick moves; drag the right side of the screen to rotate the camera; tap INTERACT near a location.
- Computer: WASD / arrow keys move; drag the right side to look; press E to interact.
- Tap the pause icon to save or restart.

## Prototype limitations
- Character, buildings and NPCs are procedural placeholders, not final art assets.
- NPCs are static; traffic, crowds, advanced collisions, indoor spaces, dialogue trees, and multiplayer are not implemented.
- Current location interaction uses simple distance checks. This is a prototype and needs testing on actual target phones before expanding.
- Save data is local to the browser/device.
